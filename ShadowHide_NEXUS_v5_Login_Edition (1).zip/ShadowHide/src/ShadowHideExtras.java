import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;

/** Extra features for ShadowHide. No files, passwords or secrets are saved by the server. */
public final class ShadowHideExtras {
    private static final int MAX_CARRIER = 30 * 1024 * 1024;
    private static final int MAX_FILE = 2 * 1024 * 1024;
    private static final long MAX_PIXELS = 16_000_000L;
    private static final byte[] FILE_MAGIC = {'S','H','F','1'};
    private ShadowHideExtras() {}

    public static void register(HttpServer server) {
        server.createContext("/api/file/hide", AuthGate.protect(e -> execute(e, ShadowHideExtras::hideFile)));
        server.createContext("/api/file/extract", AuthGate.protect(e -> execute(e, ShadowHideExtras::extractFile)));
        server.createContext("/api/analyze", AuthGate.protect(e -> execute(e, ShadowHideExtras::analyze)));
        server.createContext("/api/qr/encrypt", AuthGate.protect(e -> execute(e, ShadowHideExtras::qrEncrypt)));
        server.createContext("/api/qr/decrypt", AuthGate.protect(e -> execute(e, ShadowHideExtras::qrDecrypt)));
    }

    private interface Handler { String handle(Map<String,String> data) throws Exception; }
    private static void execute(HttpExchange e, Handler handler) throws IOException {
        if (!"POST".equalsIgnoreCase(e.getRequestMethod())) {
            SteganographyWebServer.send(e, 405, SteganographyWebServer.error("Use POST method.")); return;
        }
        try {
            Map<String,String> data = SteganographyWebServer.readForm(e);
            SteganographyWebServer.send(e, 200, handler.handle(data));
        } catch (Exception ex) {
            SteganographyWebServer.send(e, 400, SteganographyWebServer.error(ex.getMessage()));
        }
    }
    private static String required(Map<String,String> data, String key) throws Exception {
        String value = data.get(key);
        if (value == null || value.isEmpty()) throw new Exception(key + " is required.");
        return value;
    }
    private static byte[] decode(Map<String,String> data, String key, int maxBytes) throws Exception {
        String value = required(data, key);
        if (value.length() > ((long) maxBytes + 2) * 4 / 3 + 8)
            throw new Exception(key + " exceeds the file size limit.");
        try {
            byte[] result = Base64.getDecoder().decode(value);
            if (result.length > maxBytes) throw new Exception(key + " exceeds the file size limit.");
            return result;
        } catch (IllegalArgumentException e) { throw new Exception("Invalid Base64 for " + key + "."); }
    }
    private static BufferedImage image(byte[] bytes) throws Exception {
        try (ByteArrayInputStream in = new ByteArrayInputStream(bytes)) {
            BufferedImage result = ImageIO.read(in);
            if (result == null) throw new Exception("Please select a valid PNG, JPEG or BMP image.");
            if ((long) result.getWidth() * result.getHeight() > MAX_PIXELS)
                throw new Exception("Image exceeds the 16 megapixel limit.");
            return result;
        }
    }
    private static byte[] png(BufferedImage image) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        if (!ImageIO.write(image, "png", out)) throw new Exception("PNG encoding failed.");
        return out.toByteArray();
    }
    private static byte[] sha(byte[] bytes) throws Exception {
        return MessageDigest.getInstance("SHA-256").digest(bytes);
    }
    private static String hex(byte[] bytes) {
        StringBuilder result = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) result.append(String.format("%02x", b & 255));
        return result.toString();
    }
    private static String json(String value) { return "\"" + SteganographyWebServer.jsonEscape(value) + "\""; }

    private static byte[] packFile(byte[] file, String name) throws Exception {
        name = name.replace('\\', '/');
        name = name.substring(name.lastIndexOf('/') + 1).replaceAll("[\\x00-\\x1F\\x7F]", "_");
        if (name.isBlank() || name.equals(".") || name.equals("..")) name = "recovered.bin";
        byte[] nameBytes = name.getBytes(StandardCharsets.UTF_8);
        if (nameBytes.length > 180) throw new Exception("File name is too long (180 bytes max).");
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(buffer);
        out.write(FILE_MAGIC);
        out.writeShort(nameBytes.length);
        out.writeInt(file.length);
        out.write(sha(file));
        out.write(nameBytes);
        out.write(file);
        out.flush();
        return buffer.toByteArray();
    }
    private static String unpackFile(byte[] plaintext) throws Exception {
        DataInputStream in = new DataInputStream(new ByteArrayInputStream(plaintext));
        byte[] magic = new byte[4];
        in.readFully(magic);
        if (!Arrays.equals(magic, FILE_MAGIC))
            throw new Exception("This carrier contains a text message, not a hidden file.");
        int nameLen = in.readUnsignedShort();
        int length = in.readInt();
        if (nameLen < 1 || nameLen > 180 || length < 0 || length > MAX_FILE ||
                in.available() != 32 + nameLen + length)
            throw new Exception("Invalid hidden file structure.");
        byte[] expected = new byte[32]; in.readFully(expected);
        byte[] nameBytes = new byte[nameLen]; in.readFully(nameBytes);
        byte[] content = new byte[length]; in.readFully(content);
        if (!MessageDigest.isEqual(expected, sha(content)))
            throw new Exception("SHA-256 integrity verification failed.");
        String name = new String(nameBytes, StandardCharsets.UTF_8);
        name = name.replace('\\', '/');
        name = name.substring(name.lastIndexOf('/') + 1).replaceAll("[\\x00-\\x1F\\x7F]", "_");
        return "{\"success\":true,\"filename\":" + json(name) +
                ",\"sha256\":" + json(hex(expected)) +
                ",\"file\":" + json(Base64.getEncoder().encodeToString(content)) + "}";
    }

    private static String hideFile(Map<String,String> data) throws Exception {
        String media = required(data, "media");
        String password = required(data, "password");
        byte[] file = decode(data, "file", MAX_FILE);
        byte[] carrier = decode(data, "carrier", MAX_CARRIER);
        byte[] encrypted = SteganographyWebServer.encryptBytes(packFile(file, required(data, "filename")), password);
        byte[] result;
        String extension;
        switch (media) {
            case "image": {
                BufferedImage img = image(carrier);
                long capacity = (long) img.getWidth() * img.getHeight() * 3 / 8;
                if (encrypted.length > capacity)
                    throw new Exception("Image capacity is " + capacity + " bytes; use a larger image or smaller file.");
                SteganographyWebServer.embed(img, encrypted);
                result = png(img); extension = "png"; break;
            }
            case "audio":
                result = AudioSteganography.hide(carrier, encrypted);
                extension = "wav"; break;
            case "video": {
                Path output = Files.createTempFile("shadowhide_file_", ".mkv");
                try {
                    VideoSteganography.hide(carrier, encrypted, output);
                    result = Files.readAllBytes(output);
                } finally { Files.deleteIfExists(output); }
                extension = "mkv"; break;
            }
            default: throw new Exception("Choose image, audio or video.");
        }
        return "{\"success\":true,\"extension\":" + json(extension) +
                ",\"sha256\":" + json(hex(sha(result))) +
                ",\"carrier\":" + json(Base64.getEncoder().encodeToString(result)) + "}";
    }
    private static String extractFile(Map<String,String> data) throws Exception {
        String media = required(data, "media");
        String password = required(data, "password");
        byte[] carrier = decode(data, "carrier", MAX_CARRIER);
        byte[] encrypted;
        switch (media) {
            case "image": encrypted = SteganographyWebServer.extract(image(carrier)); break;
            case "audio": encrypted = AudioSteganography.extract(carrier); break;
            case "video": encrypted = VideoSteganography.extract(carrier); break;
            default: throw new Exception("Choose image, audio or video.");
        }
        return unpackFile(SteganographyWebServer.decryptBytes(encrypted, password));
    }
    private static String analyze(Map<String,String> data) throws Exception {
        byte[] originalBytes = decode(data, "original", MAX_CARRIER);
        byte[] stegoBytes = decode(data, "stego", MAX_CARRIER);
        BufferedImage a = image(originalBytes), b = image(stegoBytes);
        if (a.getWidth() != b.getWidth() || a.getHeight() != b.getHeight())
            throw new Exception("Both images must have identical dimensions.");
        long changed = 0, total = (long) a.getWidth() * a.getHeight() * 3;
        double squared = 0, absolute = 0;
        for (int y = 0; y < a.getHeight(); y++) for (int x = 0; x < a.getWidth(); x++) {
            int p = a.getRGB(x, y), q = b.getRGB(x, y);
            for (int shift : new int[]{16, 8, 0}) {
                int delta = ((p >> shift) & 255) - ((q >> shift) & 255);
                if (delta != 0) changed++;
                squared += (double) delta * delta;
                absolute += Math.abs(delta);
            }
        }
        double mse = squared / total;
        double psnr = mse == 0 ? Double.POSITIVE_INFINITY : 10 * Math.log10(65025.0 / mse);
        return "{\"success\":true,\"width\":" + a.getWidth() +
                ",\"height\":" + a.getHeight() +
                ",\"capacityBytes\":" + (total / 8) +
                ",\"mse\":" + number(mse) +
                ",\"mae\":" + number(absolute / total) +
                ",\"psnr\":" + (Double.isInfinite(psnr) ? "null" : number(psnr)) +
                ",\"changedChannels\":" + changed +
                ",\"changedPercent\":" + number(changed * 100.0 / total) +
                ",\"originalSha256\":" + json(hex(sha(originalBytes))) +
                ",\"stegoSha256\":" + json(hex(sha(stegoBytes))) + "}";
    }
    private static String number(double value) { return String.format(Locale.ROOT, "%.8f", value); }
    private static String qrEncrypt(Map<String,String> data) throws Exception {
        String message = required(data, "message");
        if (message.getBytes(StandardCharsets.UTF_8).length > 140)
            throw new Exception("QR messages must be 140 UTF-8 bytes or less.");
        byte[] encrypted = SteganographyWebServer.encryptBytes(message.getBytes(StandardCharsets.UTF_8), required(data,"password"));
        String payload = "SHQR1:" + Base64.getUrlEncoder().withoutPadding().encodeToString(encrypted);
        return "{\"success\":true,\"qrText\":" + json(payload) + "}";
    }
    private static String qrDecrypt(Map<String,String> data) throws Exception {
        String qrText = required(data, "qrText").trim();
        if (!qrText.startsWith("SHQR1:") || qrText.length() > 600)
            throw new Exception("This is not a supported ShadowHide encrypted QR code.");
        byte[] payload;
        try { payload = Base64.getUrlDecoder().decode(qrText.substring(6)); }
        catch (IllegalArgumentException e) { throw new Exception("Invalid QR code payload."); }
        String message = new String(SteganographyWebServer.decryptBytes(payload, required(data,"password")), StandardCharsets.UTF_8);
        return "{\"success\":true,\"message\":" + json(message) + "}";
    }
}
