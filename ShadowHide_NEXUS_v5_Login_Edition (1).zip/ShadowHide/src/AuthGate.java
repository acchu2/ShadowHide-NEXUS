import com.sun.net.httpserver.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class AuthGate {
  private AuthGate() {}
  private static final SecureRandom RNG = new SecureRandom();
  private static final Map<String,Long> SESSIONS = new ConcurrentHashMap<>();
  private static final Map<String,long[]> ATTEMPTS = new ConcurrentHashMap<>();
  private static final long TTL = 8*60*60*1000L;
  private static final String USER = System.getenv().getOrDefault("SHADOWHIDE_USER", "");
  private static final String PASS = System.getenv().getOrDefault("SHADOWHIDE_PASSWORD", "");
  private static boolean configured() { return !USER.isBlank() && PASS.length() >= 12; }
  private static boolean secure(HttpExchange e) { return "https".equalsIgnoreCase(e.getRequestHeaders().getFirst("X-Forwarded-Proto")); }
  private static String cookie(HttpExchange e) {
    String all=e.getRequestHeaders().getFirst("Cookie");
    if(all!=null) for(String item:all.split(";")) { String[] pair=item.trim().split("=",2); if(pair.length==2 && pair[0].equals("sh_session")) return pair[1]; }
    return "";
  }
  private static boolean authed(HttpExchange e) { Long expiry=SESSIONS.get(cookie(e)); return expiry!=null && expiry>System.currentTimeMillis(); }
  private static void respond(HttpExchange e,int code,String type,String content) throws IOException {
    byte[] b=content.getBytes(StandardCharsets.UTF_8);
    e.getResponseHeaders().set("Content-Type",type+"; charset=utf-8");
    e.getResponseHeaders().set("Cache-Control","no-store");
    e.getResponseHeaders().set("X-Content-Type-Options","nosniff");
    e.getResponseHeaders().set("X-Frame-Options","DENY");
    e.sendResponseHeaders(code,b.length); try(OutputStream o=e.getResponseBody()){o.write(b);}
  }
  private static void redirect(HttpExchange e,String path) throws IOException { e.getResponseHeaders().set("Location",path); e.getResponseHeaders().set("Cache-Control","no-store"); e.sendResponseHeaders(302,-1); e.close(); }
  public static HttpHandler protect(HttpHandler next) { return e -> {
    String path=e.getRequestURI().getPath();
    if(path.equals("/login") || path.equals("/login.html")) { if(authed(e)) redirect(e,"/"); else serveLogin(e); return; }
    if(!authed(e)) { if(path.startsWith("/api/")) respond(e,401,"application/json","{\"success\":false,\"error\":\"Please sign in\"}"); else redirect(e,"/login"); return; }
    next.handle(e);
  }; }
  private static void serveLogin(HttpExchange e) throws IOException {
    if(!e.getRequestMethod().equals("GET")){respond(e,405,"text/plain","Method not allowed");return;}
    byte[] b=java.nio.file.Files.readAllBytes(java.nio.file.Paths.get("web/login.html"));
    respond(e,200,"text/html",new String(b,StandardCharsets.UTF_8));
  }
  public static void login(HttpExchange e) throws IOException {
    if(!e.getRequestMethod().equals("POST")){respond(e,405,"application/json","{\"error\":\"Method not allowed\"}");return;}
    if(!configured()){respond(e,503,"application/json","{\"error\":\"Set SHADOWHIDE_USER and SHADOWHIDE_PASSWORD (at least 12 characters) on the server\"}");return;}
    String ip=e.getRemoteAddress().getAddress().getHostAddress(); long now=System.currentTimeMillis();
    long[] a=ATTEMPTS.computeIfAbsent(ip,k->new long[]{0,now});
    synchronized(a) {if(now-a[1]>15*60*1000){a[0]=0;a[1]=now;} if(a[0]>=8){respond(e,429,"application/json","{\"error\":\"Too many attempts. Try again in 15 minutes\"}");return;}}
    byte[] raw=e.getRequestBody().readNBytes(4097);
    if(raw.length>4096){respond(e,413,"application/json","{\"error\":\"Request too large\"}");return;}
    Map<String,String> form=new HashMap<>();
    for(String part:new String(raw,StandardCharsets.UTF_8).split("&")){String[] p=part.split("=",2);if(p.length==2)form.put(java.net.URLDecoder.decode(p[0],StandardCharsets.UTF_8),java.net.URLDecoder.decode(p[1],StandardCharsets.UTF_8));}
    boolean ok=MessageDigest.isEqual(form.getOrDefault("username","").getBytes(StandardCharsets.UTF_8),USER.getBytes(StandardCharsets.UTF_8)) && MessageDigest.isEqual(form.getOrDefault("password","").getBytes(StandardCharsets.UTF_8),PASS.getBytes(StandardCharsets.UTF_8));
    if(!ok){synchronized(a){a[0]++;}respond(e,401,"application/json","{\"error\":\"Invalid username or password\"}");return;}
    ATTEMPTS.remove(ip);byte[] token=new byte[32];RNG.nextBytes(token);String key=Base64.getUrlEncoder().withoutPadding().encodeToString(token);SESSIONS.put(key,now+TTL);
    e.getResponseHeaders().add("Set-Cookie","sh_session="+key+"; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800"+(secure(e)?"; Secure":""));
    respond(e,200,"application/json","{\"success\":true}");
  }
  public static void logout(HttpExchange e) throws IOException {
    if(!e.getRequestMethod().equals("POST")){respond(e,405,"text/plain","Method not allowed");return;}
    SESSIONS.remove(cookie(e));e.getResponseHeaders().add("Set-Cookie","sh_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0"+(secure(e)?"; Secure":""));
    respond(e,200,"application/json","{\"success\":true}");
  }
}
