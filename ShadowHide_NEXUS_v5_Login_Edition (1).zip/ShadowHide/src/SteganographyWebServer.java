
import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpExchange;

import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;

import java.security.SecureRandom;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.Arrays;

public class SteganographyWebServer {

    private static final byte[] MAGIC = {'S', 'T', 'G', '2'};
    private static final byte[] LEGACY_MAGIC = {'S', 'T', 'G', '1'};

    private static final int SALT_LENGTH = 16;
    private static final int NONCE_LENGTH = 12;
    private static final int ITERATIONS = 250000;
    private static final int LEGACY_ITERATIONS = 120000;
    private static final int MAX_FORM_BYTES = 50 * 1024 * 1024;

    public static void main(String[] args) throws Exception {

        HttpServer server = HttpServer.create(
                new InetSocketAddress(System.getenv().getOrDefault("SHADOWHIDE_HOST", "127.0.0.1"), Integer.parseInt(System.getenv().getOrDefault("PORT", System.getenv().getOrDefault("SHADOWHIDE_PORT", "8080")))), 0);

        server.createContext("/api/hide", AuthGate.protect(exchange -> handleHide(exchange)));
        server.createContext("/api/extract", AuthGate.protect(exchange -> handleExtract(exchange)));
        server.createContext("/api/audio/hide", AuthGate.protect(exchange -> handleAudioHide(exchange)));

server.createContext("/api/audio/extract", AuthGate.protect(exchange -> handleAudioExtract(exchange)));
        ShadowHideExtras.register(server);
        server.createContext("/", AuthGate.protect(exchange -> serveWebsite(exchange)));
        server.createContext("/auth/login", AuthGate::login);
        server.createContext("/auth/logout", AuthGate::logout);
        server.createContext("/api/video/hide", AuthGate.protect(exchange -> handleVideoHide(exchange)));

server.createContext("/api/video/extract", AuthGate.protect(exchange -> handleVideoExtract(exchange)));

        server.start();

        System.out.println("ShadowHide website is running!");
        System.out.println("Open http://localhost:" + server.getAddress().getPort());

    }

    // ---------------- HIDE MESSAGE ----------------

    private static void handleHide(HttpExchange exchange)
            throws IOException {

        try {
            if (!exchange.getRequestMethod().equalsIgnoreCase("POST")) {
                send(exchange, 405, error("Use POST method."));
                return;
            }

            Map<String, String> data = readForm(exchange);

            byte[] imageBytes = decodeImage(data.get("image"));

            BufferedImage image = ImageIO.read(
                    new ByteArrayInputStream(imageBytes));

            if (image == null) {
                throw new Exception("Invalid image.");
            }

            String message = data.get("message");
            String password = data.get("password");

            if (message == null || password == null ||
                    password.isEmpty()) {
                throw new Exception("Message and password are required.");
            }

            byte[] payload = encrypt(message, password);

            long capacity = (long) image.getWidth()
                    * image.getHeight() * 3 / 8;

            if (payload.length > capacity) {
                throw new Exception("Image is too small for this message.");
            }

            embed(image, payload);

            ByteArrayOutputStream output = new ByteArrayOutputStream();
            ImageIO.write(image, "png", output);

            String result = Base64.getEncoder()
                    .encodeToString(output.toByteArray());

            send(exchange, 200,
                    "{\"success\":true,\"image\":\"" + result + "\"}");

        } catch (Exception e) {
            send(exchange, 400, error(e.getMessage()));
        }
    }

    // ---------------- EXTRACT MESSAGE ----------------

    private static void handleExtract(HttpExchange exchange)
            throws IOException {

        try {
            if (!exchange.getRequestMethod().equalsIgnoreCase("POST")) {
                send(exchange, 405, error("Use POST method."));
                return;
            }

            Map<String, String> data = readForm(exchange);

            byte[] imageBytes = decodeImage(data.get("image"));

            BufferedImage image = ImageIO.read(
                    new ByteArrayInputStream(imageBytes));

            if (image == null) {
                throw new Exception("Invalid image.");
            }

            String password = data.get("password");

            if (password == null || password.isEmpty()) {
                throw new Exception("Password is required.");
            }

            byte[] payload = extract(image);
            String message = decrypt(payload, password);

            send(exchange, 200,
                    "{\"success\":true,\"message\":\""
                    + jsonEscape(message) + "\"}");

        } catch (Exception e) {
            send(exchange, 400, error(e.getMessage()));
        }
    }

    // ---------------- ENCRYPTION ----------------
    private static void handleAudioHide(HttpExchange exchange) throws IOException {
    try {
        if (!exchange.getRequestMethod().equalsIgnoreCase("POST")) {
            send(exchange, 405, error("Use POST method."));
            return;
        }

        Map<String, String> data = readForm(exchange);

        String audioData = data.get("audio");
        String message = data.get("message");
        String password = data.get("password");

        if (audioData == null || audioData.isEmpty()) {
            throw new Exception("Please select a WAV audio file.");
        }

        if (message == null || password == null || password.isEmpty()) {
            throw new Exception("Message and password are required.");
        }

        byte[] wavBytes = Base64.getDecoder().decode(audioData);
        byte[] payload = encrypt(message, password);
        byte[] result = AudioSteganography.hide(wavBytes, payload);

        String encoded = Base64.getEncoder().encodeToString(result);

        send(exchange, 200,
                "{\"success\":true,\"audio\":\"" + encoded + "\"}");

    } catch (Exception e) {
        send(exchange, 400, error(e.getMessage()));
    }
}

    private static byte[] encrypt(String message, String password)
            throws Exception {
        return encryptBytes(message.getBytes(StandardCharsets.UTF_8), password);
    }

    static byte[] encryptBytes(byte[] plaintext, String password) throws Exception {
        if (password == null || password.isEmpty()) throw new Exception("Password is required.");
        SecureRandom random = new SecureRandom();

        byte[] salt = new byte[SALT_LENGTH];
        byte[] nonce = new byte[NONCE_LENGTH];

        random.nextBytes(salt);
        random.nextBytes(nonce);

        PBEKeySpec spec = new PBEKeySpec(
                password.toCharArray(), salt, ITERATIONS, 256);

        SecretKeyFactory factory = SecretKeyFactory.getInstance(
                "PBKDF2WithHmacSHA256");

        byte[] keyBytes = factory.generateSecret(spec).getEncoded();
        spec.clearPassword();

        SecretKey key = new SecretKeySpec(keyBytes, "AES");

        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");

        cipher.init(Cipher.ENCRYPT_MODE, key,
                new GCMParameterSpec(128, nonce));

        byte[] encrypted;
        try { encrypted = cipher.doFinal(plaintext); }
        finally { Arrays.fill(keyBytes, (byte) 0); }

        ByteArrayOutputStream output = new ByteArrayOutputStream();
        DataOutputStream data = new DataOutputStream(output);

        data.write(MAGIC);
        data.write(salt);
        data.write(nonce);
        data.writeInt(encrypted.length);
        data.write(encrypted);

        return output.toByteArray();
    }

    // ---------------- DECRYPTION ----------------

    private static String decrypt(byte[] payload, String password) throws Exception {
        return new String(decryptBytes(payload, password), StandardCharsets.UTF_8);
    }

    static byte[] decryptBytes(byte[] payload, String password) throws Exception {
        if (password == null || password.isEmpty()) throw new Exception("Password is required.");
        if (payload == null || payload.length < 52) throw new Exception("Invalid hidden payload.");
        DataInputStream data = new DataInputStream(new ByteArrayInputStream(payload));
        byte[] magic = new byte[4];
        data.readFully(magic);
        int rounds;
        if (Arrays.equals(magic, MAGIC)) rounds = ITERATIONS;
        else if (Arrays.equals(magic, LEGACY_MAGIC)) rounds = LEGACY_ITERATIONS;
        else throw new Exception("No ShadowHide payload found.");

        byte[] salt = new byte[SALT_LENGTH];
        byte[] nonce = new byte[NONCE_LENGTH];
        data.readFully(salt);
        data.readFully(nonce);
        int length = data.readInt();
        if (length < 16 || length != data.available()) throw new Exception("Invalid hidden payload length.");
        byte[] encrypted = new byte[length];
        data.readFully(encrypted);

        PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, rounds, 256);
        byte[] keyBytes;
        try {
            keyBytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                    .generateSecret(spec).getEncoded();
        } finally { spec.clearPassword(); }
        try {
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(keyBytes, "AES"),
                    new GCMParameterSpec(128, nonce));
            try { return cipher.doFinal(encrypted); }
            catch (javax.crypto.AEADBadTagException e) {
                throw new Exception("Incorrect password or modified hidden data.");
            }
        } finally { Arrays.fill(keyBytes, (byte) 0); }
    }
private static void handleAudioExtract(HttpExchange exchange) throws IOException {
    try {
        if (!exchange.getRequestMethod().equalsIgnoreCase("POST")) {
            send(exchange, 405, error("Use POST method."));
            return;
        }

        Map<String, String> data = readForm(exchange);

        String audioData = data.get("audio");
        String password = data.get("password");

        if (audioData == null || audioData.isEmpty()) {
            throw new Exception("Please select a WAV audio file.");
        }

        if (password == null || password.isEmpty()) {
            throw new Exception("Password is required.");
        }

        byte[] wavBytes = Base64.getDecoder().decode(audioData);
        byte[] payload = AudioSteganography.extract(wavBytes);
        String message = decrypt(payload, password);

        send(exchange, 200,
                "{\"success\":true,\"message\":\"" + jsonEscape(message) + "\"}");

    } catch (Exception e) {
        send(exchange, 400, error(e.getMessage()));
    }
}
    // ---------------- HIDE DATA IN IMAGE ----------------

    static void embed(BufferedImage image, byte[] payload) {

        int bitIndex = 0;
        int totalBits = payload.length * 8;

        for (int y = 0; y < image.getHeight() && bitIndex < totalBits; y++) {
            for (int x = 0; x < image.getWidth() && bitIndex < totalBits; x++) {

                int rgb = image.getRGB(x, y);

                int red = (rgb >> 16) & 255;
                int green = (rgb >> 8) & 255;
                int blue = rgb & 255;

                if (bitIndex < totalBits) {
                    red = setBit(red, payload, bitIndex++);
                }

                if (bitIndex < totalBits) {
                    green = setBit(green, payload, bitIndex++);
                }

                if (bitIndex < totalBits) {
                    blue = setBit(blue, payload, bitIndex++);
                }

                int newRgb = (rgb & 0xFF000000)
                        | (red << 16)
                        | (green << 8)
                        | blue;

                image.setRGB(x, y, newRgb);
            }
        }
    }

    private static int setBit(int value, byte[] data, int bitIndex) {

        int bit = (data[bitIndex / 8] >> (7 - bitIndex % 8)) & 1;

        return (value & 254) | bit;
    }

    // ---------------- EXTRACT DATA FROM IMAGE ----------------

   
static byte[] extract(BufferedImage image) throws Exception {
    long capacityBits = (long) image.getWidth() * image.getHeight() * 3;
    if (capacityBits < 36L * 8) throw new Exception("Image too small to contain a payload.");
    byte[] header = readEmbeddedBytes(image, 0, 36);
    if (!((header[0] == 'S' && header[1] == 'T' && header[2] == 'G') &&
            (header[3] == '1' || header[3] == '2'))) {
        throw new Exception("No hidden message found. Use the downloaded stego PNG.");
    }
    int length = ((header[32] & 255) << 24) | ((header[33] & 255) << 16)
            | ((header[34] & 255) << 8) | (header[35] & 255);
    if (length < 16 || (long) (36 + length) * 8 > capacityBits)
        throw new Exception("Invalid hidden payload length.");
    byte[] payload = new byte[36 + length];
    System.arraycopy(header, 0, payload, 0, 36);
    byte[] rest = readEmbeddedBytes(image, 36, length);
    System.arraycopy(rest, 0, payload, 36, length);
    return payload;
}

private static byte[] readEmbeddedBytes(BufferedImage image, int startByte, int count) {
    byte[] result = new byte[count];
    int width = image.getWidth();
    long bit = (long) startByte * 8;
    for (int i = 0; i < count; i++) {
        int value = 0;
        for (int b = 0; b < 8; b++, bit++) {
            int pixel = (int) (bit / 3);
            int rgb = image.getRGB(pixel % width, pixel / width);
            int channel = (int) (bit % 3);
            int low = channel == 0 ? (rgb >> 16) & 1 :
                    channel == 1 ? (rgb >> 8) & 1 : rgb & 1;
            value = (value << 1) | low;
        }
        result[i] = (byte) value;
    }
    return result;
}

static Map<String, String> readForm(HttpExchange exchange)
        throws IOException {

    byte[] input = exchange.getRequestBody().readNBytes(MAX_FORM_BYTES + 1);
    if (input.length > MAX_FORM_BYTES) throw new IOException("Request exceeds 50 MB limit.");
    String body = new String(input, StandardCharsets.UTF_8);

    Map<String, String> result = new HashMap<>();

    for (String pair : body.split("&")) {
        String[] parts = pair.split("=", 2);

        String key = URLDecoder.decode(
                parts[0], StandardCharsets.UTF_8);

        String value = parts.length > 1
                ? URLDecoder.decode(parts[1], StandardCharsets.UTF_8)
                : "";

        result.put(key, value);
    }

    return result;
}

private static byte[] decodeImage(String imageData) {

    if (imageData == null || imageData.isEmpty()) {
        throw new IllegalArgumentException("Please select an image.");
    }

    return Base64.getDecoder().decode(imageData);
}

private static void serveWebsite(HttpExchange exchange)
        throws IOException {

    if (!exchange.getRequestMethod().equalsIgnoreCase("GET")) {
        send(exchange, 405, error("Use GET method.")); return;
    }
    String requestedPath = exchange.getRequestURI().getPath();

    if (requestedPath.equals("/")) {
        requestedPath = "/index.html";
    }

    Path webRoot = Paths.get("web").toAbsolutePath().normalize();
    Path file = webRoot.resolve(requestedPath.substring(1)).normalize();

    if (!file.startsWith(webRoot) || !Files.isRegularFile(file)) {
        send(exchange, 404, "File not found.");
        return;
    }

    String contentType = "application/octet-stream";
    String name = file.getFileName().toString();

    if (name.endsWith(".html")) {
        contentType = "text/html; charset=UTF-8";
    } else if (name.endsWith(".css")) {
        contentType = "text/css; charset=UTF-8";
    } else if (name.endsWith(".svg")) {
        contentType = "image/svg+xml";
    } else if (name.endsWith(".js")) {
        contentType = "application/javascript; charset=UTF-8";
    }

    byte[] bytes = Files.readAllBytes(file);

    exchange.getResponseHeaders().set("Content-Type", contentType);
    exchange.getResponseHeaders().set("X-Content-Type-Options", "nosniff");
    exchange.getResponseHeaders().set("Cache-Control", "no-store");
    exchange.sendResponseHeaders(200, bytes.length);

    try (OutputStream out = exchange.getResponseBody()) {
        out.write(bytes);
    }
}

static String error(String message) {
    if (message == null) {
        message = "Unknown error.";
    }

    return "{\"success\":false,\"error\":\""
            + jsonEscape(message) + "\"}";
}

static String jsonEscape(String value) {
    if (value == null) return "";
    StringBuilder out = new StringBuilder(value.length() + 16);
    for (int i = 0; i < value.length(); i++) {
        char c = value.charAt(i);
        switch (c) {
            case '\"': out.append("\\\""); break;
            case '\\': out.append("\\\\"); break;
            case '\n': out.append("\\n"); break;
            case '\r': out.append("\\r"); break;
            case '\t': out.append("\\t"); break;
            default:
                if (c < 0x20) out.append(String.format(java.util.Locale.ROOT, "\\u%04x", (int) c));
                else out.append(c);
        }
    }
    return out.toString();
}

static void send(HttpExchange exchange, int status, String response)
        throws IOException {

    byte[] bytes = response.getBytes(StandardCharsets.UTF_8);

    exchange.getResponseHeaders().set(
            "Content-Type", "application/json; charset=UTF-8");

    exchange.sendResponseHeaders(status, bytes.length);

    try (OutputStream output = exchange.getResponseBody()) {
        output.write(bytes);
    }
}
private static void handleVideoHide(HttpExchange exchange) throws IOException {
    try {
        if (!exchange.getRequestMethod().equalsIgnoreCase("POST")) {
            send(exchange, 405, error("Use POST method."));
            return;
        }

        Map<String, String> data = readForm(exchange);

        String videoData = data.get("video");
        String message = data.get("message");
        String password = data.get("password");

        if (videoData == null || videoData.isEmpty()) {
            throw new Exception("Please select an MP4 video.");
        }

        if (message == null || message.isEmpty()
                || password == null || password.isEmpty()) {
            throw new Exception("Message and password are required.");
        }

        byte[] videoBytes = Base64.getDecoder().decode(videoData);
        byte[] payload = encrypt(message, password);

        java.nio.file.Path output =
                java.nio.file.Files.createTempFile("shadowhide_", ".mkv");

        try {
            VideoSteganography.hide(videoBytes, payload, output);

            byte[] result = java.nio.file.Files.readAllBytes(output);
            String encoded = Base64.getEncoder().encodeToString(result);

            send(exchange, 200,
                    "{\"success\":true,\"video\":\"" + encoded + "\"}");
        } finally {
            java.nio.file.Files.deleteIfExists(output);
        }

    } catch (Exception e) {
        send(exchange, 400, error(e.getMessage()));
    }
}
private static void handleVideoExtract(HttpExchange exchange) throws IOException {
    try {
        if (!exchange.getRequestMethod().equalsIgnoreCase("POST")) {
            send(exchange, 405, error("Use POST method."));
            return;
        }

        Map<String, String> data = readForm(exchange);

        String videoData = data.get("video");
        String password = data.get("password");

        if (videoData == null || videoData.isEmpty()) {
            throw new Exception("Please select a video file.");
        }

        if (password == null || password.isEmpty()) {
            throw new Exception("Password is required.");
        }

        byte[] videoBytes = Base64.getDecoder().decode(videoData);

        byte[] payload = VideoSteganography.extract(videoBytes);

        String message = decrypt(payload, password);

        send(exchange, 200,
                "{\"success\":true,\"message\":\""
                + jsonEscape(message) + "\"}");

    } catch (Exception e) {
        send(exchange, 400, error(e.getMessage()));
    }
}
}
