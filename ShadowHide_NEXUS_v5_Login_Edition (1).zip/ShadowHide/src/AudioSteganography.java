
import javax.sound.sampled.*;
import java.io.*;

public class AudioSteganography {

    private static final byte[] MAGIC = {'A', 'U', 'D', '1'};
    private static final int HEADER_SIZE = 8;

    private static boolean isSupported(AudioFormat format) {
        return AudioFormat.Encoding.PCM_SIGNED.equals(format.getEncoding())
                && format.getSampleSizeInBits() == 16
                && !format.isBigEndian()
                && format.getFrameSize() == format.getChannels() * 2;
    }

    public static byte[] hide(byte[] wavBytes, byte[] payload)
            throws Exception {

        AudioInputStream input = AudioSystem.getAudioInputStream(
                new ByteArrayInputStream(wavBytes));

        AudioFormat format = input.getFormat();

        if (!isSupported(format)) {
            input.close();
            throw new Exception("Only 16-bit PCM WAV files are supported.");
        }

        byte[] audioData = input.readAllBytes();
        input.close();

        if (audioData.length % 2 != 0) {
            throw new Exception("Invalid WAV audio data.");
        }

        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        DataOutputStream header = new DataOutputStream(buffer);

        header.write(MAGIC);
        header.writeInt(payload.length);
        header.write(payload);
        header.flush();

        byte[] data = buffer.toByteArray();
        int sampleCount = audioData.length / 2;

        if ((long) data.length * 8 > sampleCount) {
            throw new Exception("Audio file is too small for this message.");
        }

        int bitIndex = 0;

        for (byte value : data) {
            for (int bit = 7; bit >= 0; bit--) {
                int hiddenBit = (value >>> bit) & 1;
                int position = bitIndex * 2;

                audioData[position] =
                        (byte) ((audioData[position] & 0xFE) | hiddenBit);

                bitIndex++;
            }
        }

        ByteArrayOutputStream output = new ByteArrayOutputStream();

        AudioInputStream result = new AudioInputStream(
                new ByteArrayInputStream(audioData),
                format,
                audioData.length / format.getFrameSize());

        AudioSystem.write(result, AudioFileFormat.Type.WAVE, output);
        result.close();

        return output.toByteArray();
    }

    public static byte[] extract(byte[] wavBytes) throws Exception {

        AudioInputStream input = AudioSystem.getAudioInputStream(
                new ByteArrayInputStream(wavBytes));

        AudioFormat format = input.getFormat();

        if (!isSupported(format)) {
            input.close();
            throw new Exception("Only 16-bit PCM WAV files are supported.");
        }

        byte[] audioData = input.readAllBytes();
        input.close();

        if (audioData.length % 2 != 0) {
            throw new Exception("Invalid WAV audio data.");
        }

        int sampleCount = audioData.length / 2;

        if (sampleCount < HEADER_SIZE * 8) {
            throw new Exception("No hidden message found.");
        }

        byte[] header = readBytes(audioData, 0, HEADER_SIZE);

        for (int i = 0; i < MAGIC.length; i++) {
            if (header[i] != MAGIC[i]) {
                throw new Exception("No hidden message found.");
            }
        }

        int length = ((header[4] & 0xFF) << 24)
                | ((header[5] & 0xFF) << 16)
                | ((header[6] & 0xFF) << 8)
                | (header[7] & 0xFF);

        if (length < 0 ||
                (long) (HEADER_SIZE + length) * 8 > sampleCount) {
            throw new Exception("Invalid hidden message length.");
        }

        return readBytes(audioData, HEADER_SIZE, length);
    }

    private static byte[] readBytes(
            byte[] audioData, int startByte, int byteCount) {

        byte[] result = new byte[byteCount];

        int startBit = startByte * 8;

        for (int i = 0; i < byteCount; i++) {
            int value = 0;

            for (int bit = 7; bit >= 0; bit--) {
                int position = (startBit + i * 8 + (7 - bit)) * 2;
                int hiddenBit = audioData[position] & 1;

                value |= hiddenBit << bit;
            }

            result[i] = (byte) value;
        }

        return result;
    }
}
