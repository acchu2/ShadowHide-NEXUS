import java.io.*;
import java.nio.file.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

public class VideoSteganography {

    // Hide encrypted bytes inside the first video frame
    public static void hide(byte[] videoBytes, byte[] payload, Path outputVideo)
            throws Exception {

        Path temp = Files.createTempDirectory("shadowhide_video_");

        try {
            Path input = temp.resolve("input.mp4");
            Path frame = temp.resolve("frame.png");
            Path modified = temp.resolve("modified.png");

            Files.write(input, videoBytes);

            run("ffmpeg", "-y", "-i", input.toString(),
                    "-frames:v", "1", frame.toString());

            BufferedImage image = ImageIO.read(frame.toFile());

            if (image == null) {
                throw new Exception("Unable to read video frame.");
            }

            // Hide payload in image pixels
            byte[] data = new byte[payload.length + 4];

            int length = payload.length;

            data[0] = (byte) (length >>> 24);
            data[1] = (byte) (length >>> 16);
            data[2] = (byte) (length >>> 8);
            data[3] = (byte) length;

            System.arraycopy(payload, 0, data, 4, payload.length);

            int totalBits = data.length * 8;
            int capacity = image.getWidth() * image.getHeight() * 3;

            if (totalBits > capacity) {
                throw new Exception("Message is too large for video frame.");
            }

            int bit = 0;

            for (int y = 0; y < image.getHeight() && bit < totalBits; y++) {
                for (int x = 0; x < image.getWidth() && bit < totalBits; x++) {

                    int rgb = image.getRGB(x, y);

                    int r = (rgb >> 16) & 255;
                    int g = (rgb >> 8) & 255;
                    int b = rgb & 255;

                    if (bit < totalBits) {
                        r = (r & 254) | getBit(data, bit++);
                    }

                    if (bit < totalBits) {
                        g = (g & 254) | getBit(data, bit++);
                    }

                    if (bit < totalBits) {
                        b = (b & 254) | getBit(data, bit++);
                    }

                    image.setRGB(x, y,
                            (255 << 24) | (r << 16) | (g << 8) | b);
                }
            }

            ImageIO.write(image, "png", modified.toFile());

            // Encode using lossless FFV1 so hidden bits survive
            run("ffmpeg", "-y", "-i", input.toString(),
                    "-i", modified.toString(),
                    "-filter_complex",
                    "[0:v]select='not(eq(n,0))',setpts=PTS-STARTPTS[rest];" +
                    "[1:v][rest]concat=n=2:v=1:a=0[v]",
                    "-map", "[v]",
                    "-c:v", "ffv1",
                    outputVideo.toString());

        } finally {
            deleteDirectory(temp);
        }
    }

    // Extract hidden bytes from the first frame
    public static byte[] extract(byte[] videoBytes) throws Exception {

        Path temp = Files.createTempDirectory("shadowhide_extract_");

        try {
            Path input = temp.resolve("input.mkv");
            Path frame = temp.resolve("frame.png");

            Files.write(input, videoBytes);

            run("ffmpeg", "-y", "-i", input.toString(),
                    "-frames:v", "1", frame.toString());

            BufferedImage image = ImageIO.read(frame.toFile());

            if (image == null) {
                throw new Exception("Unable to read video frame.");
            }

            int length = 0;

            for (int i = 0; i < 32; i++) {
                length = (length << 1) | readBit(image, i);
            }

            int capacityBytes =
                    (image.getWidth() * image.getHeight() * 3) / 8;

            if (length <= 0 || length > capacityBytes - 4) {
                throw new Exception("No valid hidden message found.");
            }

            byte[] payload = new byte[length];

            for (int i = 0; i < length * 8; i++) {
                int value = readBit(image, i + 32);

                payload[i / 8] |= value << (7 - (i % 8));
            }

            return payload;

        } finally {
            deleteDirectory(temp);
        }
    }

    private static int getBit(byte[] data, int bit) {
        return (data[bit / 8] >> (7 - (bit % 8))) & 1;
    }

    private static int readBit(BufferedImage image, int bit) {

        int pixel = bit / 3;
        int channel = bit % 3;

        int x = pixel % image.getWidth();
        int y = pixel / image.getWidth();

        int rgb = image.getRGB(x, y);

        if (channel == 0) return (rgb >> 16) & 1;
        if (channel == 1) return (rgb >> 8) & 1;

        return rgb & 1;
    }

    private static void run(String... command) throws Exception {

        ProcessBuilder builder = new ProcessBuilder(command);
        builder.redirectErrorStream(true);

        Process process = builder.start();

        try (InputStream stream = process.getInputStream()) {
            stream.transferTo(OutputStream.nullOutputStream());
        }

        if (process.waitFor() != 0) {
            throw new Exception("FFmpeg processing failed.");
        }
    }

    private static void deleteDirectory(Path dir) throws IOException {

        if (!Files.exists(dir)) return;

        try (var paths = Files.walk(dir)) {
            paths.sorted((a, b) -> b.compareTo(a))
                    .forEach(path -> {
                        try {
                            Files.deleteIfExists(path);
                        } catch (IOException ignored) {
                        }
                    });
        }
    }
}
