# ShadowHide 2.0 — Change log

## Added

- Upgraded dashboard with in-memory session counts and recent activity.
- Live password strength meters for image, audio, video, file and QR hiding.
- Binary file hiding/extraction in image, WAV and MP4/MKV carriers, with SHA-256 verification.
- Image comparison: MSE, MAE, PSNR, changed-channel percentage, capacity and amplified difference canvas.
- SHA-256 hash calculator and expected-hash comparison.
- Encrypted QR payload generation and decryption, local QR code drawing, optional browser-based image scanning.
- Sample cover media, Windows run script and user guide.

## Security and compatibility

- New payloads use `STG2` header and 250,000 PBKDF2-HMAC-SHA256 iterations with AES-256-GCM.
- Original `STG1` payloads remain supported with 120,000 PBKDF2 iterations.
- Improved image payload extraction performance; removes verbose payload debugging.
- Added 50 MB request body limit and stricter encrypted payload length validation.
- Added file name sanitization and integrity checks.
- Bundled MIT-licensed QR generator; no CDN required.

## Known constraints

- The current video workflow outputs FFV1 MKV and does not preserve the original audio track.
- 16-bit little-endian PCM WAV only for audio LSB.
- QR image scanning requires a browser with BarcodeDetector support; copy/paste fallback is always available.
- Maximum hidden file size 2 MB; maximum file-hiding carrier 30 MB; maximum image analysis input 30 MB.
- The app is designed for single-user localhost operation, not internet deployment.
