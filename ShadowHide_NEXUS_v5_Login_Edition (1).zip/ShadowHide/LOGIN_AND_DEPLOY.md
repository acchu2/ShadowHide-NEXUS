# ShadowHide NEXUS v5 — Login Edition

## New design
A cinematic login page with moving star particles, neon aurora, cyber grid, glass card, show/hide password and logout. All Java API endpoints require a valid server-side session cookie. Sessions last up to 8 hours. Login attempts are limited to 8 per 15 minutes per IP (in-memory).

## Windows PowerShell local run
Open PowerShell inside the inner `ShadowHide` folder. Set your own credentials **in that terminal session** (never put real credentials in GitHub):

```powershell
$env:SHADOWHIDE_USER = "operator"
$env:SHADOWHIDE_PASSWORD = "replace-with-your-own-long-password"
javac -encoding UTF-8 -d out (Get-ChildItem .\src -Filter "*.java" | ForEach-Object { $_.FullName })
java -cp out SteganographyWebServer
```

Open http://localhost:8080. Use the username/password you configured. Do not type the `PS C:\...>` prompt. Stop any older server first (Ctrl+C).

## Render public hosting
Push the **contents of this inner ShadowHide folder** to your private GitHub repository root. Deploy as Docker web service on Render. In Render Environment, add `SHADOWHIDE_USER` and `SHADOWHIDE_PASSWORD` (at least 12 characters), and keep them secret. `render.yaml` also marks these values as manual secrets for blueprint deploys. Never upload your actual password to GitHub.

## Security notes
This is a single-operator demonstration login, **not** a production multi-user identity system. No account signup, recovery, persistent sessions, or per-user file isolation. Sessions reset on restart. Render HTTPS termination is required for public access; `Secure` cookie flag is set when the proxy sends `X-Forwarded-Proto: https`. Use a trusted reverse proxy. Avoid uploading real confidential files to a publicly hosted demonstration. Add CSRF protection, persistent account management, rate limiting shared across instances, upload restrictions, and security review before production use.
