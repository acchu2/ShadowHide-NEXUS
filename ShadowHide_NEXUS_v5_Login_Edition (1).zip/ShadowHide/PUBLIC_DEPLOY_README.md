# ShadowHide NEXUS v4 — Public HTTPS deployment

## Important security notice
This is a demonstration application, not a hardened production service. Public visitors can submit files for server-side processing. Before distributing the link widely, add authentication, rate limiting, per-request CPU/time limits, stricter media validation, and security monitoring. Never upload real confidential data during public demos. Requests may be handled concurrently; memory usage may grow with large files. Render's free instance is resource-limited and may sleep when idle.

## Render + GitHub steps
1. Extract this ZIP. The deployable application is the **ShadowHide** folder containing Dockerfile, src, and web.
2. Create a **private** GitHub repository and upload the **contents** of the ShadowHide folder to its root (not an extra nested ShadowHide folder). Do not upload sensitive files.
3. Sign in at https://dashboard.render.com and connect GitHub.
4. New > Web Service > choose the repository.
5. Runtime/Language: **Docker**. Dockerfile path: **./Dockerfile**. Choose a supported plan (Free if available). Set environment variables PORT=10000 and SHADOWHIDE_HOST=0.0.0.0 (Dockerfile already supplies defaults).
6. Create Web Service. Wait for the deployment to finish. Copy the actual **https://...onrender.com** URL shown by Render.
7. Test the home page and a harmless small image hide/extract flow from a phone and laptop. Video uses bundled ffmpeg and may require more memory/CPU than a free instance offers.

## Local Windows run (same as before)
From the ShadowHide folder:
`javac -d out (Get-ChildItem .\src -Filter "*.java" | ForEach-Object { $_.FullName })`
`java -cp out SteganographyWebServer`
Then browse http://localhost:8080.

## Notes
- HTTPS is terminated by Render. The Java HTTP server listens on HTTP internally.
- Do not publish your real passwords, secret files, or test datasets in the GitHub repository.
- This package does not create a live public URL: you must authorize GitHub/Render deployment.
- The app is stateless by design for this demo; files created during processing should not be relied upon to persist between restarts.
