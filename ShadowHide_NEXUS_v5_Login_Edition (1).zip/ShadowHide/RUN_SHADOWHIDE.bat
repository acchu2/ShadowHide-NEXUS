@echo off
cd /d "%~dp0"
if "%SHADOWHIDE_USER%"=="" set /p SHADOWHIDE_USER=Choose operator username: 
if "%SHADOWHIDE_PASSWORD%"=="" set /p SHADOWHIDE_PASSWORD=Choose a password (12+ characters): 
if not exist out mkdir out
javac -encoding UTF-8 -d out src\*.java
if errorlevel 1 pause & exit /b 1
java -cp out SteganographyWebServer
pause
