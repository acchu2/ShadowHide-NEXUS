# ShadowHide 2.0 — Secure Image, Audio and Video Steganography

**Upgraded from your original ShadowHide project.** No college details, accounts, database, cloud APIs or external services are required.

## Start in Windows 11 (easy method)

1. Extract `ShadowHide_Upgraded.zip` to your Desktop. You should see a folder named `ShadowHide`.
2. Keep your old ShadowHide project in a separate backup folder.
3. Ensure **Java JDK 17+** is installed. Check `java -version` and `javac -version`.
4. For video steganography, ensure **FFmpeg** is installed and `ffmpeg -version` works.
5. Double-click **`RUN_SHADOWHIDE.bat`** in the extracted `ShadowHide` folder. Keep its terminal window open.
6. Open **Chrome** and visit **http://localhost:8080**.
7. If port 8080 is already in use, close the previous Java server (or see the manual method below).

**Do not open `web/index.html` by double-clicking.** The site needs the Java server to process the encryption and steganography requests.

## Manual VS Code method

Open the extracted `ShadowHide` folder in VS Code. In Terminal → New Terminal, enter:

```powershell
javac --release 17 -encoding UTF-8 -d out src\SteganographyWebServer.java src\AudioSteganography.java src\VideoSteganography.java src\ShadowHideExtras.java
java -cp out SteganographyWebServer
```

Then visit `http://localhost:8080` in Chrome. **Do not type** the `PS C:\...>` prompt shown by PowerShell.

If `Address already in use: bind` appears, you already have a server running on 8080. Stop that server with `Ctrl+C` or use an alternate port:

```powershell
$env:SHADOWHIDE_PORT="8081"
java -cp out SteganographyWebServer
```

Then open `http://localhost:8081`.

## Seven website sections

1. **Image Steganography:** Hide and extract password-encrypted text. Output is PNG. Cover inputs may be PNG/JPEG/BMP; stego PNG must not be converted to lossy JPEG.
2. **Audio Steganography:** Hide and extract text in **16-bit little-endian PCM WAV** audio. Other WAV formats are rejected with an explanation.
3. **Video Steganography:** Hide and extract text using the first frame of an MP4 cover, then save as **lossless FFV1 MKV**. FFmpeg must be on PATH. **This video implementation does not preserve the original audio track.**
4. **Secure File Hiding (NEW):** Embed and recover a binary file (TXT/PDF/ZIP/etc.) in an image, WAV or MP4 video carrier. The file is encrypted, and its SHA-256 is verified after extraction. Secret files up to **2 MB**; carriers up to **30 MB**. Carrier must have enough pixel/sample capacity.
5. **Image Analyzer (NEW):** Compare two images with identical dimensions. Calculates **MSE, MAE, PSNR, changed RGB channel percentage, and embedding capacity**. Includes an amplified difference visualization. These metrics cannot prove that an image contains a secret.
6. **Encryption & Integrity (NEW):** New payloads use **AES-256-GCM**, **PBKDF2-HMAC-SHA256** with **250,000 iterations**, a random **16-byte salt** and **12-byte nonce**. Older `STG1` payloads (120,000 iterations) remain decryptable. Use the SHA-256 verifier to compare file digests.
7. **Encrypted QR Sharing (NEW):** Encrypt a message of up to **140 UTF-8 bytes** into a QR image, then decrypt with the password. The QR generator is bundled locally; no external QR service is used. Chrome/Edge may support scanning an uploaded QR image via `BarcodeDetector`. If the browser does not support scanning, **paste the encrypted `SHQR1:...` text** from the sender instead. Share the password separately from the QR code.

## Try the sample files

The `demo/` folder contains `cover.png`, `cover.jpg`, `cover.wav` and `cover.mp4`. These are example carrier files with no secret data.

**Image example:** Go to Image Steganography → select `demo/cover.png` → type a message and password → Hide → download `ShadowHide_Stego.png` → select that PNG in Extract → enter the same password → Extract.

**File example:** Go to Secure File Hiding → select `Image` → choose `demo/cover.png` → choose a small TXT file → enter a password → Hide → download stego PNG. In the Recover panel, select `Image`, choose the downloaded stego PNG, enter password and Extract. Your original file name and bytes are recovered.

**Analyzer example:** Compare `demo/cover.png` with the stego PNG you just created.

**QR example:** Create an encrypted QR message, download the QR image, and copy the encrypted `SHQR1:...` payload. Paste the payload into the decrypt panel with the same password. To use the QR image directly, try Scan Selected Image in a compatible browser.

## Security and privacy notes

- The Java server binds only to `127.0.0.1`, not to your local network or the internet.
- No accounts or cloud uploads. The server uses memory and temporary video processing files, deleting temporary files when the operation completes.
- The dashboard's activity counters are **session-only**; they reset when the page reloads and do not store file names or secret contents.
- **Never forget the password:** there is no password recovery. Wrong passwords or tampered ciphertext are rejected by AES-GCM authentication.
- The strength meter is only a visual estimate. Use a long, unique password.
- QR codes **contain encrypted data, not the password**. Anyone with both the QR payload and password can decrypt it.
- The server has request-size and media-size limits, but this is a **local academic demo**, not a hardened multi-user production service. Do not expose the server to the public internet.
- Image quality metrics and SHA-256 comparison do not constitute steganalysis or malware scanning.

## Project files

```text
ShadowHide/
├── RUN_SHADOWHIDE.bat
├── README_START_HERE.md
├── CHANGELOG.md
├── demo/                     # sample carrier files
├── src/
│   ├── SteganographyWebServer.java  # original APIs + upgraded crypto
│   ├── AudioSteganography.java      # original audio LSB
│   ├── VideoSteganography.java      # original video FFV1/FFmpeg
│   └── ShadowHideExtras.java       # file, analyzer, QR APIs
├── web/
│   ├── index.html
│   ├── style.css
│   ├── app.js
│   ├── upgrades.js
│   ├── qr-vendor.js
│   └── THIRD_PARTY_LICENSES.txt
└── out/                      # compiled classes
```

## Test coverage

Tested on Java 17+ in a Linux development container (your Windows 11 environment may differ):

- Java compilation and static file serving
- Image text hide/extract, including Unicode and incorrect password rejection
- Audio and video text hide/extract
- File hide/extract in image, WAV and MP4/MKV carriers, including SHA-256 verification
- Image MSE/PSNR analysis
- QR encrypt/decrypt
- Legacy `STG1` image extraction
- Browser HTML/JS loading and offline QR generator rendering

**Video requires FFmpeg on Windows.** Image, WAV, and QR features work without FFmpeg.
