// ShadowHide NEXUS — visual effects and local image-capacity estimator.
(() => {
  'use strict';
  const canvas = document.getElementById('nexusBackground');
  const ctx = canvas?.getContext('2d');
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (ctx && !reduced) {
    let w = 0, h = 0, dots = [];
    function resize() {
      w = canvas.width = window.innerWidth * Math.min(devicePixelRatio || 1, 2);
      h = canvas.height = window.innerHeight * Math.min(devicePixelRatio || 1, 2);
      dots = Array.from({length: Math.min(75, Math.floor(w * h / 23000))}, () => ({x:Math.random()*w,y:Math.random()*h,v:.15+Math.random()*.45,r:1+Math.random()*1.4}));
    }
    window.addEventListener('resize', resize, {passive:true}); resize();
    let frame = 0;
    function draw() {
      ctx.clearRect(0,0,w,h);
      ctx.strokeStyle='rgba(57,148,255,.055)';ctx.lineWidth=1;
      const gap=80*Math.min(devicePixelRatio||1,2);
      for(let x=0;x<w;x+=gap){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,h);ctx.stroke()}
      for(let y=0;y<h;y+=gap){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(w,y);ctx.stroke()}
      dots.forEach((p,i)=>{p.y-=p.v;if(p.y<0)p.y=h;ctx.fillStyle=i%4===0?'rgba(185,111,255,.65)':'rgba(78,222,255,.58)';ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,Math.PI*2);ctx.fill()});
      frame++;requestAnimationFrame(draw);
    }
    draw();
    document.addEventListener('visibilitychange',()=>{});
  }
  const input=document.getElementById('capacityImage'), msg=document.getElementById('capacityMessage');
  const status=document.getElementById('capacityStatus'), available=document.getElementById('capacityAvailable'), required=document.getElementById('capacityRequired'), pct=document.getElementById('capacityPercent'), ring=document.getElementById('capacityRing');
  let maxBytes=null;
  const fmt=n=>n.toLocaleString()+' bytes';
  function update(){
    const textBytes=new TextEncoder().encode(msg.value).length;
    // STG2 header (36 bytes), AES-GCM tag (16 bytes), salt (16 bytes), IV (12 bytes), plus margin.
    const estimated=textBytes+80;
    required.textContent=fmt(estimated);
    available.textContent=maxBytes===null?'—':fmt(maxBytes);
    if(maxBytes===null){pct.textContent='—';ring.style.background='conic-gradient(#4deaff 0%,#182d4a 0%)';return}
    const used=maxBytes?Math.min(100,Math.round(100*estimated/maxBytes)):100;
    pct.textContent=used+'%';ring.style.background=`conic-gradient(${estimated>maxBytes?'#ff688b':'#4deaff'} ${used}%,#182d4a ${used}%)`;
    status.textContent=estimated>maxBytes?'⚠ Estimated message is too large. Choose a bigger image.':`✓ Estimated payload fits. ${Math.max(0,maxBytes-estimated).toLocaleString()} bytes remaining.`;
    status.style.color=estimated>maxBytes?'#ff91a8':'#8af3c1';
  }
  msg?.addEventListener('input',update);
  input?.addEventListener('change',()=>{
    maxBytes=null;
    const file=input.files?.[0];if(!file){status.textContent='Choose an image to begin analysis.';update();return}
    const url=URL.createObjectURL(file), image=new Image();
    image.onload=()=>{maxBytes=Math.max(0,Math.floor(image.naturalWidth*image.naturalHeight*3/8)-36);status.textContent=`Image: ${image.naturalWidth} × ${image.naturalHeight} pixels`;URL.revokeObjectURL(url);update()};
    image.onerror=()=>{URL.revokeObjectURL(url);status.textContent='Could not read this image. Choose PNG or JPEG.';update()};
    image.src=url;
  });
  update();
})();
