
// Convert an image file into Base64
function imageToBase64(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();

        reader.onload = () => {
            resolve(reader.result.split(",")[1]);
        };

        reader.onerror = () => {
            reject(new Error("Unable to read image."));
        };

        reader.readAsDataURL(file);
    });
}

// Hide secret message
document.getElementById("hideButton").addEventListener("click", async () => {

    const imageFile = document.getElementById("hideImage").files[0];
    const message = document.getElementById("secretMessage").value;
    const password = document.getElementById("hidePassword").value;

    const status = document.getElementById("hideStatus");
    const downloadLink = document.getElementById("downloadLink");

    downloadLink.style.display = "none";

    if (!imageFile || !message || !password) {
        status.textContent = "Please select an image and enter a message and password.";
        return;
    }

    try {
        status.textContent = "Hiding your message... Please wait.";

        const image = await imageToBase64(imageFile);

        const form = new URLSearchParams();
        form.append("image", image);
        form.append("message", message);
        form.append("password", password);

        const response = await fetch("/api/hide", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            body: form
        });

        const result = await response.json();

        if (!response.ok || !result.success) {
            throw new Error(result.error || "Unable to hide message.");
        }

        downloadLink.href = "data:image/png;base64," + result.image;
        downloadLink.download = "ShadowHide_Stego.png";
        downloadLink.style.display = "inline-block";

        status.textContent = "Success! Your secret message is hidden inside the image.";
        window.shadowRecord?.("hide", "image message");

    } catch (error) {
        status.textContent = "Error: " + error.message;
    }
});

// Extract secret message
document.getElementById("extractButton").addEventListener("click", async () => {

    const imageFile = document.getElementById("extractImage").files[0];
    const password = document.getElementById("extractPassword").value;

    const status = document.getElementById("extractStatus");
    const output = document.getElementById("extractedMessage");

    output.value = "";

    if (!imageFile || !password) {
        status.textContent = "Please select a stego image and enter the password.";
        return;
    }

    try {
        status.textContent = "Extracting your message... Please wait.";

        const image = await imageToBase64(imageFile);

        const form = new URLSearchParams();
        form.append("image", image);
        form.append("password", password);

        const response = await fetch("/api/extract", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            body: form
        });

        const result = await response.json();

        if (!response.ok || !result.success) {
            throw new Error(result.error || "Unable to extract message.");
        }

        output.value = result.message;
        status.textContent = "Success! Your secret message has been extracted.";
        window.shadowRecord?.("extract", "image message");

    } catch (error) {
        status.textContent = "Error: " + error.message;
    }
});


// Convert WAV audio file into Base64
function audioToBase64(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();

        reader.onload = () => {
            resolve(reader.result.split(",")[1]);
        };

        reader.onerror = () => {
            reject(new Error("Unable to read audio file."));
        };

        reader.readAsDataURL(file);
    });
}

// Hide a secret message inside WAV audio
document.getElementById("audioHideButton").addEventListener("click", async () => {

    const audioFile = document.getElementById("audioHideFile").files[0];
    const message = document.getElementById("audioSecretMessage").value;
    const password = document.getElementById("audioHidePassword").value;

    const status = document.getElementById("audioHideStatus");
    const downloadLink = document.getElementById("audioDownloadLink");

    downloadLink.style.display = "none";

    if (!audioFile || !message.trim() || !password) {
        status.textContent = "Please select a WAV file, message and password.";
        return;
    }

    try {
        status.textContent = "Hiding message in audio... Please wait.";

        const audioBase64 = await audioToBase64(audioFile);

        const formData = new URLSearchParams();
        formData.append("audio", audioBase64);
        formData.append("message", message);
        formData.append("password", password);

        const response = await fetch("/api/audio/hide", {
            method: "POST",
            body: formData
        });

        const result = await response.json();

        if (!response.ok || !result.success) {
            throw new Error(result.error || "Audio hiding failed.");
        }

        const binary = atob(result.audio);
        const bytes = Uint8Array.from(binary, c => c.charCodeAt(0));
        const blob = new Blob([bytes], { type: "audio/wav" });

        if (downloadLink.href.startsWith("blob:")) {
            URL.revokeObjectURL(downloadLink.href);
        }

        downloadLink.href = URL.createObjectURL(blob);
        downloadLink.download = "ShadowHide_Stego_Audio.wav";
        downloadLink.textContent = "Download Stego Audio";
        downloadLink.style.display = "inline-block";

        status.textContent = "Message hidden successfully!";
        window.shadowRecord?.("hide", "media message");

    } catch (error) {
        status.textContent = "Error: " + error.message;
    }
});

// Extract a secret message from WAV audio
document.getElementById("audioExtractButton").addEventListener("click", async () => {

    const audioFile = document.getElementById("audioExtractFile").files[0];
    const password = document.getElementById("audioExtractPassword").value;

    const status = document.getElementById("audioExtractStatus");
    const output = document.getElementById("audioExtractedMessage");

    output.value = "";

    if (!audioFile || !password) {
        status.textContent = "Please select a WAV file and enter the password.";
        return;
    }

    try {
        status.textContent = "Extracting secret message... Please wait.";

        const audioBase64 = await audioToBase64(audioFile);

        const formData = new URLSearchParams();
        formData.append("audio", audioBase64);
        formData.append("password", password);

        const response = await fetch("/api/audio/extract", {
            method: "POST",
            body: formData
        });

        const result = await response.json();

        if (!response.ok || !result.success) {
            throw new Error(result.error || "Audio extraction failed.");
        }

        output.value = result.message;
        status.textContent = "Message extracted successfully!";
        window.shadowRecord?.("extract", "audio message");

    } catch (error) {
        status.textContent = "Error: " + error.message;
    }
});
// Convert video file to Base64
function videoToBase64(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();

        reader.onload = () => {
            resolve(reader.result.split(",")[1]);
        };

        reader.onerror = () => {
            reject(new Error("Unable to read video file."));
        };

        reader.readAsDataURL(file);
    });
}

// Hide secret message inside video
document.getElementById("videoHideButton").addEventListener("click", async () => {

    const videoFile = document.getElementById("videoHideFile").files[0];
    const message = document.getElementById("videoSecretMessage").value;
    const password = document.getElementById("videoHidePassword").value;

    const status = document.getElementById("videoHideStatus");
    const downloadLink = document.getElementById("videoDownloadLink");

    downloadLink.style.display = "none";

    if (!videoFile || !message.trim() || !password) {
        status.textContent = "Please select an MP4 video, message and password.";
        return;
    }

    try {
        status.textContent = "Hiding message in video... Please wait.";

        const videoBase64 = await videoToBase64(videoFile);

        const formData = new URLSearchParams();
        formData.append("video", videoBase64);
        formData.append("message", message);
        formData.append("password", password);

        const response = await fetch("/api/video/hide", {
            method: "POST",
            body: formData
        });

        const result = await response.json();

        if (!response.ok || !result.success) {
            throw new Error(result.error || "Video hiding failed.");
        }

        const binary = atob(result.video);
        const bytes = Uint8Array.from(binary, c => c.charCodeAt(0));
        const blob = new Blob([bytes], { type: "video/x-matroska" });

        if (downloadLink.href.startsWith("blob:")) {
            URL.revokeObjectURL(downloadLink.href);
        }

        downloadLink.href = URL.createObjectURL(blob);
        downloadLink.download = "ShadowHide_Stego_Video.mkv";
        downloadLink.textContent = "Download Stego Video";
        downloadLink.style.display = "inline-block";

        status.textContent = "Message hidden successfully!";
        window.shadowRecord?.("hide", "media message");

    } catch (error) {
        status.textContent = "Error: " + error.message;
    }
});
// Extract secret message from stego video
document.getElementById("videoExtractButton").addEventListener("click", async () => {

    const videoFile = document.getElementById("videoExtractFile").files[0];
    const password = document.getElementById("videoExtractPassword").value;

    const status = document.getElementById("videoExtractStatus");
    const extractedMessage = document.getElementById("videoExtractedMessage");

    extractedMessage.value = "";

    if (!videoFile || !password) {
        status.textContent = "Please select a stego MKV video and enter password.";
        return;
    }

    try {
        status.textContent = "Extracting secret message... Please wait.";

        const videoBase64 = await videoToBase64(videoFile);

        const formData = new URLSearchParams();
        formData.append("video", videoBase64);
        formData.append("password", password);

        const response = await fetch("/api/video/extract", {
            method: "POST",
            body: formData
        });

        const result = await response.json();

        if (!response.ok || !result.success) {
            throw new Error(result.error || "Video extraction failed.");
        }

        extractedMessage.value = result.message;
        status.textContent = "Secret message extracted successfully!";
        window.shadowRecord?.("extract", "video message");

    } catch (error) {
        status.textContent = "Error: " + error.message;
    }
});