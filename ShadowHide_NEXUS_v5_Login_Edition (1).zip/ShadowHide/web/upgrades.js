/* ShadowHide v2.0 — local-only upgrades; no external services or telemetry. */
(() => {
    'use strict';
    const $ = id => document.getElementById(id);
    const operations = [];
    const counts = { hide: 0, extract: 0 };

    window.shadowRecord = (action, kind) => {
        if (action === 'hide') counts.hide++;
        if (action === 'extract') counts.extract++;
        operations.unshift({ action, kind, time: new Date().toLocaleTimeString() });
        if (operations.length > 6) operations.pop();
        $('totalOps').textContent = counts.hide + counts.extract;
        $('hideOps').textContent = counts.hide;
        $('extractOps').textContent = counts.extract;
        const list = $('activityList');
        list.replaceChildren();
        for (const item of operations) {
            const div = document.createElement('div');
            div.className = 'activity-item';
            div.textContent = (item.action === 'hide' ? '🔒 Hidden · ' : '🔓 Extracted · ') + item.kind;
            const time = document.createElement('time');
            time.textContent = item.time;
            div.append(time);
            list.append(div);
        }
    };

    const strength = password => {
        if (!password) return [0, 'Enter a password', '#64748b'];
        let score = 0;
        if (password.length >= 8) score++;
        if (password.length >= 12) score++;
        if (/[a-z]/.test(password) && /[A-Z]/.test(password)) score++;
        if (/\d/.test(password)) score++;
        if (/[^A-Za-z0-9]/.test(password)) score++;
        if (password.length < 8) score = Math.min(score, 1);
        if (score <= 1) return [20, 'Weak · use 12+ characters', '#fb7185'];
        if (score <= 3) return [60, 'Medium · add length/variety', '#fbbf24'];
        return [100, 'Strong (estimated)', '#34d399'];
    };
    for (const meter of document.querySelectorAll('.password-meter')) {
        const input = $(meter.dataset.password);
        input.addEventListener('input', () => {
            const [percent, label, color] = strength(input.value);
            const fill = meter.querySelector('.meter-fill');
            fill.style.width = percent + '%'; fill.style.background = color;
            meter.querySelector('small').textContent = label;
        });
    }

    const readBase64 = file => new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result).split(',')[1]);
        reader.onerror = () => reject(new Error('Unable to read file.'));
        reader.readAsDataURL(file);
    });
    const post = async (url, data) => {
        const response = await fetch(url, { method: 'POST', body: new URLSearchParams(data) });
        let result;
        try { result = await response.json(); }
        catch { throw new Error('Invalid response from local Java server.'); }
        if (!response.ok || !result.success) throw new Error(result.error || 'Operation failed.');
        return result;
    };
    const setDownload = (anchor, base64, filename, mime) => {
        if (anchor.dataset.objectUrl) URL.revokeObjectURL(anchor.dataset.objectUrl);
        const binary = atob(base64);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
        const url = URL.createObjectURL(new Blob([bytes], { type: mime }));
        anchor.href = url; anchor.dataset.objectUrl = url;
        anchor.download = filename; anchor.textContent = '⬇ Download ' + filename;
        anchor.style.display = 'inline-block';
    };
    const setBusy = (id, busy) => { $(id).disabled = busy; };
    const limits = (file, max, name) => {
        if (!file) throw new Error('Select ' + name + '.');
        if (file.size > max) throw new Error(name + ' exceeds ' + (max / 1024 / 1024) + ' MB.');
    };
    const carrierFormats = {
        image: { hide: '.png,.jpg,.jpeg,.bmp,image/*', extract: '.png,image/png', mime: 'image/png', extension: 'png' },
        audio: { hide: '.wav,audio/wav', extract: '.wav,audio/wav', mime: 'audio/wav', extension: 'wav' },
        video: { hide: '.mp4,video/mp4', extract: '.mkv,video/x-matroska', mime: 'video/x-matroska', extension: 'mkv' }
    };
    for (const [mode, selectId, fileId] of [
        ['hide', 'fileHideMedia', 'fileHideCarrier'],
        ['extract', 'fileExtractMedia', 'fileExtractCarrier']
    ]) {
        $(selectId).addEventListener('change', () => {
            $(fileId).accept = carrierFormats[$(selectId).value][mode];
            $(fileId).value = '';
        });
    }
    $('fileHideButton').addEventListener('click', async () => {
        const status = $('fileHideStatus'), anchor = $('fileHideDownload');
        anchor.style.display = 'none'; $('fileCarrierHash').textContent = '';
        setBusy('fileHideButton', true);
        try {
            const media = $('fileHideMedia').value;
            const carrier = $('fileHideCarrier').files[0], file = $('fileSecret').files[0];
            limits(carrier, 30 * 1024 * 1024, 'cover media');
            limits(file, 2 * 1024 * 1024, 'secret file');
            if (!$('fileHidePassword').value) throw new Error('Enter a password.');
            status.textContent = 'Encrypting and embedding your file…';
            const result = await post('/api/file/hide', {
                media, carrier: await readBase64(carrier), file: await readBase64(file),
                filename: file.name, password: $('fileHidePassword').value
            });
            setDownload(anchor, result.carrier, 'ShadowHide_File_Stego.' + result.extension, carrierFormats[media].mime);
            $('fileCarrierHash').textContent = 'Stego carrier SHA-256: ' + result.sha256;
            status.textContent = 'Success! Download the stego carrier. Keep your password safe.';
            window.shadowRecord('hide', media + ' file');
        } catch (e) { status.textContent = 'Error: ' + e.message; }
        finally { setBusy('fileHideButton', false); }
    });
    $('fileExtractButton').addEventListener('click', async () => {
        const status = $('fileExtractStatus'), anchor = $('fileExtractDownload');
        anchor.style.display = 'none'; $('fileExtractHash').textContent = '';
        setBusy('fileExtractButton', true);
        try {
            const media = $('fileExtractMedia').value;
            const carrier = $('fileExtractCarrier').files[0];
            limits(carrier, 30 * 1024 * 1024, 'stego carrier');
            if (!$('fileExtractPassword').value) throw new Error('Enter a password.');
            status.textContent = 'Extracting, decrypting and verifying the hidden file…';
            const result = await post('/api/file/extract', {
                media, carrier: await readBase64(carrier), password: $('fileExtractPassword').value
            });
            setDownload(anchor, result.file, result.filename, 'application/octet-stream');
            $('fileExtractHash').textContent = 'Verified secret file SHA-256: ' + result.sha256;
            status.textContent = 'Success! SHA-256 integrity verified. Download your recovered file.';
            window.shadowRecord('extract', media + ' file');
        } catch (e) { status.textContent = 'Error: ' + e.message; }
        finally { setBusy('fileExtractButton', false); }
    });

    const previewUrls = {};
    for (const [inputId, imgId] of [['analyzeOriginal', 'previewOriginal'], ['analyzeStego', 'previewStego']]) {
        $(inputId).addEventListener('change', () => {
            if (previewUrls[imgId]) URL.revokeObjectURL(previewUrls[imgId]);
            const file = $(inputId).files[0];
            $(imgId).hidden = !file;
            if (file) { previewUrls[imgId] = URL.createObjectURL(file); $(imgId).src = previewUrls[imgId]; }
        });
    }
    async function drawDifference(a, b) {
        const [imA, imB] = await Promise.all([createImageBitmap(a), createImageBitmap(b)]);
        try {
            const scale = Math.min(1, 800 / Math.max(imA.width, imA.height));
            const w = Math.max(1, Math.round(imA.width * scale)), h = Math.max(1, Math.round(imA.height * scale));
            const canvas = $('differenceCanvas'); canvas.width = w; canvas.height = h;
            const temp = document.createElement('canvas'); temp.width = w; temp.height = h;
            const ctx = temp.getContext('2d', { willReadFrequently: true });
            ctx.drawImage(imA, 0, 0, w, h); const left = ctx.getImageData(0, 0, w, h);
            ctx.clearRect(0, 0, w, h); ctx.drawImage(imB, 0, 0, w, h);
            const right = ctx.getImageData(0, 0, w, h);
            const out = canvas.getContext('2d');
            const diff = out.createImageData(w, h);
            for (let i = 0; i < left.data.length; i += 4) {
                for (let c = 0; c < 3; c++) diff.data[i + c] = Math.min(255, Math.abs(left.data[i + c] - right.data[i + c]) * 48);
                diff.data[i + 3] = 255;
            }
            out.putImageData(diff, 0, 0);
        } finally { imA.close(); imB.close(); }
    }
    $('analyzeButton').addEventListener('click', async () => {
        const status = $('analyzeStatus'); $('analysisResults').hidden = true;
        setBusy('analyzeButton', true);
        try {
            const a = $('analyzeOriginal').files[0], b = $('analyzeStego').files[0];
            limits(a, 30 * 1024 * 1024, 'original image'); limits(b, 30 * 1024 * 1024, 'stego image');
            status.textContent = 'Comparing RGB channels…';
            const result = await post('/api/analyze', { original: await readBase64(a), stego: await readBase64(b) });
            $('metricMse').textContent = result.mse.toFixed(6);
            $('metricPsnr').textContent = result.psnr === null ? '∞ dB' : result.psnr.toFixed(2) + ' dB';
            $('metricChanged').textContent = result.changedPercent.toFixed(3) + '%';
            $('metricCapacity').textContent = (result.capacityBytes / 1024).toFixed(1) + ' KB';
            await drawDifference(a, b);
            $('analysisResults').hidden = false;
            status.textContent = `Compared ${result.width} × ${result.height} images. Quality metrics calculated successfully.`;
        } catch (e) { status.textContent = 'Error: ' + e.message; }
        finally { setBusy('analyzeButton', false); }
    });

    let lastHash = '';
    $('hashButton').addEventListener('click', async () => {
        const status = $('hashStatus'); $('hashOutput').value = ''; lastHash = '';
        try {
            const file = $('hashFile').files[0]; limits(file, 100 * 1024 * 1024, 'file');
            status.textContent = 'Calculating SHA-256 locally…';
            const bytes = await file.arrayBuffer();
            const digest = await crypto.subtle.digest('SHA-256', bytes);
            lastHash = Array.from(new Uint8Array(digest), b => b.toString(16).padStart(2, '0')).join('');
            $('hashOutput').value = lastHash;
            compareHash();
        } catch (e) { status.textContent = 'Error: ' + e.message; }
    });
    const compareHash = () => {
        const expected = $('expectedHash').value.trim().toLowerCase();
        $('hashStatus').textContent = !lastHash ? 'Calculate a file hash first.' : !expected ? 'SHA-256 calculated. Paste an expected hash to compare.' :
            !/^[a-f0-9]{64}$/.test(expected) ? 'Expected hash must contain exactly 64 hexadecimal characters.' :
            expected === lastHash ? '✓ MATCH: File SHA-256 matches the expected hash.' : '✕ MISMATCH: File differs from the expected hash.';
    };
    $('expectedHash').addEventListener('input', compareHash);
    $('copyHashButton').addEventListener('click', async () => {
        if (!lastHash) { $('hashStatus').textContent = 'Calculate a hash first.'; return; }
        try { await navigator.clipboard.writeText(lastHash); $('hashStatus').textContent = 'Hash copied.'; }
        catch { $('hashStatus').textContent = 'Select and copy the hash manually.'; }
    });

    function drawQR(text) {
        if (!window.ShadowQR) throw new Error('QR generator library is unavailable.');
        const qr = new window.ShadowQR(0, window.ShadowQRErrorCorrectLevel.L);
        qr.addData(text); qr.make();
        const count = qr.getModuleCount(), quiet = 4, scale = Math.max(4, Math.floor(400 / (count + quiet * 2)));
        const canvas = $('qrCanvas');
        canvas.width = canvas.height = (count + quiet * 2) * scale;
        const ctx = canvas.getContext('2d'); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = '#101827';
        for (let row = 0; row < count; row++) for (let col = 0; col < count; col++)
            if (qr.isDark(row, col)) ctx.fillRect((col + quiet) * scale, (row + quiet) * scale, scale, scale);
        $('qrDownload').href = canvas.toDataURL('image/png');
    }
    $('qrCreateButton').addEventListener('click', async () => {
        const status = $('qrCreateStatus'); $('qrResult').hidden = true;
        setBusy('qrCreateButton', true);
        try {
            const message = $('qrMessage').value, password = $('qrPassword').value;
            if (!message || !password) throw new Error('Enter a message and password.');
            if (new TextEncoder().encode(message).length > 140) throw new Error('Message exceeds 140 UTF-8 bytes.');
            status.textContent = 'Encrypting QR message…';
            const result = await post('/api/qr/encrypt', { message, password });
            drawQR(result.qrText);
            $('qrEncoded').value = result.qrText;
            $('qrResult').hidden = false;
            status.textContent = 'Encrypted QR created. Share the password separately.';
            window.shadowRecord('hide', 'QR message');
        } catch (e) { status.textContent = 'Error: ' + e.message; }
        finally { setBusy('qrCreateButton', false); }
    });
    $('qrCopyButton').addEventListener('click', async () => {
        try { await navigator.clipboard.writeText($('qrEncoded').value); $('qrCreateStatus').textContent = 'Encrypted QR payload copied.'; }
        catch { $('qrCreateStatus').textContent = 'Select and copy the QR payload manually.'; }
    });
    $('qrScanButton').addEventListener('click', async () => {
        const status = $('qrDecryptStatus');
        try {
            const file = $('qrScanFile').files[0]; limits(file, 15 * 1024 * 1024, 'QR image');
            if (typeof BarcodeDetector === 'undefined') throw new Error('QR image scanning is not supported by this browser. Paste the encrypted QR payload instead.');
            const detector = new BarcodeDetector({ formats: ['qr_code'] });
            const image = await createImageBitmap(file);
            try {
                const found = await detector.detect(image);
                if (!found.length) throw new Error('No QR code found in image.');
                $('qrInput').value = found[0].rawValue;
                status.textContent = 'QR scanned. Enter the password and click Decrypt.';
            } finally { image.close(); }
        } catch (e) { status.textContent = 'Error: ' + e.message; }
    });
    $('qrDecryptButton').addEventListener('click', async () => {
        const status = $('qrDecryptStatus'); $('qrRecovered').value = '';
        setBusy('qrDecryptButton', true);
        try {
            const result = await post('/api/qr/decrypt', {
                qrText: $('qrInput').value.trim(), password: $('qrDecryptPassword').value
            });
            $('qrRecovered').value = result.message;
            status.textContent = 'Encrypted QR message recovered successfully.';
            window.shadowRecord('extract', 'QR message');
        } catch (e) { status.textContent = 'Error: ' + e.message; }
        finally { setBusy('qrDecryptButton', false); }
    });
})();
