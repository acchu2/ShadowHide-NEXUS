ShadowHide NEXUS v3.0

New: animated cyber grid, neon/glass dashboard styling, responsive Stego Capacity Lab.

Run on Windows:
1. Extract ZIP.
2. Open the ShadowHide folder in VS Code.
3. In PowerShell: javac -d out (Get-ChildItem .\src -Filter "*.java" | ForEach-Object { $_.FullName })
4. java -cp out SteganographyWebServer
5. Open http://localhost:8080 and press Ctrl+F5 for fresh CSS/JS.

Stego Capacity Lab estimates text payload sizes; server validates final capacity.
Animations respect reduced-motion accessibility preferences.
