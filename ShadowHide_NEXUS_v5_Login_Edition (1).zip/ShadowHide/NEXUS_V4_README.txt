SHADOWHIDE NEXUS v4 — Immersive Neon Edition

Features: cinematic portal background, animated neon rings, glowing HUD, glass cards, live password-strength meters, password visibility toggles. Existing server and tools are unchanged.

WINDOWS POWERSHELL:
cd "C:\Users\admin\Downloads\ShadowHide_NEXUS_v4\ShadowHide"
javac -d out (Get-ChildItem .\src -Filter "*.java" | ForEach-Object { $_.FullName })
java -cp out SteganographyWebServer

Open http://localhost:8080 and press Ctrl+Shift+R. Stop previous server with Ctrl+C first.
